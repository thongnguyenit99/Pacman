﻿Họ tên: Nguyễn Văn Thông
MSSV: 	1760197.
Email: nvthong.it@gmail.com
Lớp: 17ck2

Mức độ hoàn thành deadline: 85% (Em giải thích các file yêu cầu còn lũng cũng
 và có phần sai câu 2.6 khi viết báo cáo, vì chưa ra kết quả đúng!)