﻿Họ tên: Nguyễn Văn Thông
MSSV: 	1760197.
Email: nvthong.it@gmail.com
Lớp: 17ck2

Mức độ hoàn thành deadline: 65% (Em giải thích các file yêu cầu còn lũng cũng
 và có phần sai câu 2.7 vavf 2.8 khi viết báo cáo, vì chưa ra kết quả đúng!)