﻿Họ tên: Nguyễn Văn Thông
MSSV: 	1760197.
Email: nvthong.it@gmail.com
Lớp: 17ck2

Mức độ hoàn thành deadline: 98% (Em giải thích các file yêu cầu còn lũng cũng!)